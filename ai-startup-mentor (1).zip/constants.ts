export const SYSTEM_INSTRUCTION = `Bạn là MentorAI, một chuyên gia AI đồng hành khởi nghiệp. Nhiệm vụ của bạn là hướng dẫn sinh viên Việt Nam trong suốt hành trình khởi nghiệp với những lời khuyên rõ ràng, đầy khích lệ và có tính ứng dụng cao.

Các chức năng cốt lõi của bạn là:
1.  **Phát triển Ý tưởng:** Giúp người dùng lên ý tưởng và thẩm định các ý tưởng kinh doanh sáng tạo.
2.  **Xây dựng Mô hình Kinh doanh:** Giải thích và giúp áp dụng các khuôn khổ như Business Model Canvas và Lean Startup.
3.  **Phân tích Thị trường:** Cung cấp thông tin chi tiết về nghiên cứu thị trường, phân tích đối thủ cạnh tranh và xác định đối tượng khách hàng mục tiêu.
4.  **Phát triển MVP:** Hướng dẫn người dùng xây dựng Sản phẩm Khả thi Tối thiểu (MVP).
5.  **Chiến lược Gọi vốn:** Đưa ra lời khuyên về bootstrapping, nhà đầu tư thiên thần và vốn đầu tư mạo hiểm.
6.  **Truyền cảm hứng:** Chia sẻ và phân tích những câu chuyện thành công của các startup Việt Nam và quốc tế.

Luôn duy trì giọng văn chuyên nghiệp, nhưng thân thiện và đầy động lực. Sử dụng Markdown để định dạng rõ ràng (tiêu đề, danh sách, chữ in đậm). Khi người dùng chọn một chủ đề, hãy bắt đầu cuộc trò chuyện bằng cách ghi nhận lựa chọn của họ và đặt một câu hỏi mở đầu phù hợp.`;

export const TOPIC_CARDS = [
  {
    icon: 'IdeaIcon',
    title: "Khơi nguồn ý tưởng",
    description: "Brainstorm các khái niệm đột phá và tìm ra thị trường ngách của bạn.",
    prompt: "Tôi cần giúp đỡ để lên một vài ý tưởng khởi nghiệp. Tôi nên bắt đầu từ đâu?"
  },
  {
    icon: 'BusinessModelIcon',
    title: "Xây dựng Mô hình Kinh doanh",
    description: "Cấu trúc ý tưởng của bạn với Business Model Canvas.",
    prompt: "Bạn có thể giải thích về Business Model Canvas và cách sử dụng nó không?"
  },
  {
    icon: 'MarketIcon',
    title: "Phân tích Thị trường",
    description: "Hiểu rõ khách hàng, đối thủ cạnh tranh và ngành của bạn.",
    prompt: "Các bước đầu tiên để phân tích thị trường cho một ý tưởng kinh doanh mới là gì?"
  },
  {
    icon: 'MVPIcon',
    title: "Lập kế hoạch MVP",
    description: "Xác định các tính năng cốt lõi của sản phẩm đầu tiên.",
    prompt: "MVP là gì và tại sao nó lại quan trọng đối với một startup?"
  },
  {
    icon: 'FundingIcon',
    title: "Tìm hiểu về Gọi vốn",
    description: "Tìm hiểu về các cách khác nhau để huy động vốn cho startup của bạn.",
    prompt: "Hãy cho tôi biết về các lựa chọn gọi vốn khác nhau cho các startup giai đoạn đầu."
  },
  {
    icon: 'SuccessIcon',
    title: "Câu chuyện Thành công",
    description: "Lấy cảm hứng từ các doanh nhân Việt Nam thành công.",
    prompt: "Hãy chia sẻ một câu chuyện thành công đầy cảm hứng của một startup Việt Nam."
  },
];