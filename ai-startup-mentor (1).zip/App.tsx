import React, { useState, useRef } from 'react';
import { GoogleGenAI, Chat } from "@google/genai";
import { Message, Role } from './types';
import { SYSTEM_INSTRUCTION } from './constants';
import { Header } from './components/Header';
import { ChatPanel } from './components/ChatPanel';
import { Dashboard } from './components/Dashboard';

const App: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [isSidebarOpen, setSidebarOpen] = useState<boolean>(false);

  const chatSessionRef = useRef<Chat | null>(null);

  const handleNewChat = () => {
    setMessages([]);
    setError(null);
    chatSessionRef.current = null;
    setSidebarOpen(true);
  };
  
  const handleSend = async (prompt?: string) => {
    const textToSend = prompt || input;
    if (!textToSend.trim()) return;

    setSidebarOpen(true);

    const userMessage: Message = { role: Role.USER, content: textToSend };
    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);
    setError(null);

    try {
      if (!chatSessionRef.current) {
        if (!process.env.API_KEY) {
          throw new Error("API_KEY chưa được định cấu hình.");
        }
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
        chatSessionRef.current = ai.chats.create({
          model: 'gemini-2.5-flash',
          config: {
            systemInstruction: SYSTEM_INSTRUCTION,
          },
        });
      }

      const stream = await chatSessionRef.current.sendMessageStream({ message: textToSend });

      setMessages(prev => [...prev, { role: Role.MODEL, content: '' }]);

      for await (const chunk of stream) {
        const chunkText = chunk.text;
        setMessages(prev => {
          const newMessages = [...prev];
          const lastMessage = newMessages[newMessages.length - 1];
          if (lastMessage.role === Role.MODEL) {
            lastMessage.content += chunkText;
          }
          return newMessages;
        });
      }

    } catch (e: any) {
      setError(`Lỗi: ${e.message}. Vui lòng kiểm tra API key của bạn và thử lại.`);
      const errorMessage = {role: Role.MODEL, content: `Xin lỗi, tôi đã gặp sự cố. Vui lòng thử lại sau.`};
      setMessages(prev => {
          const lastMessage = prev[prev.length - 1];
          // if model message is empty, replace it with error
          if (lastMessage?.role === Role.MODEL && lastMessage.content === '') {
              return [...prev.slice(0, -1), errorMessage];
          }
          return [...prev, errorMessage];
      });
      console.error(e);
    } finally {
      setIsLoading(false);
    }
  };

  const handleTopicSelect = (prompt: string) => {
    if (messages.length > 0) {
      // Create a new chat session when a new topic is selected from the dashboard
      handleNewChat();
      // Use a timeout to allow state to clear before sending the new message
      setTimeout(() => handleSend(prompt), 100);
    } else {
      handleSend(prompt);
    }
  };
  
  return (
    <div className="flex flex-col h-screen bg-[#0D1117] text-white font-sans">
      <Header 
        onMenuClick={() => setSidebarOpen(!isSidebarOpen)}
        onNewChatClick={handleNewChat}
      />
      <div className="flex flex-1 overflow-hidden relative">
         <div className={`absolute inset-0 bg-black/50 z-20 md:hidden ${isSidebarOpen ? 'block' : 'hidden'}`} onClick={() => setSidebarOpen(false)}></div>
         <ChatPanel 
            messages={messages}
            input={input}
            setInput={setInput}
            handleSend={() => handleSend()}
            isLoading={isLoading}
            error={error}
            isOpen={isSidebarOpen}
            onClose={() => setSidebarOpen(false)}
         />
         <main className="flex-1 flex flex-col">
            <Dashboard 
                onTopicSelect={handleTopicSelect} 
                onStartConversation={() => setSidebarOpen(true)} 
            />
         </main>
      </div>
    </div>
  );
};

export default App;