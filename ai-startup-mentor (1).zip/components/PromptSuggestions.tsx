

import React from 'react';
// FIX: Changed import from SUGGESTION_PROMPTS to TOPIC_CARDS as SUGGESTION_PROMPTS is not exported from constants.
import { TOPIC_CARDS } from '../constants';

interface PromptSuggestionsProps {
  onSuggestionClick: (suggestion: string) => void;
}

export const PromptSuggestions: React.FC<PromptSuggestionsProps> = ({ onSuggestionClick }) => {
  return (
    <div className="flex-1 flex flex-col items-center justify-center p-8 text-center text-white">
      <div className="bg-teal-500 rounded-full p-4 mb-4">
        <i className="fa-solid fa-lightbulb text-4xl text-white"></i>
      </div>
      <h1 className="text-3xl font-bold mb-2">Xin chào! Tôi là MentorAI.</h1>
      <p className="text-gray-400 mb-8 max-w-lg">
        Tôi ở đây để giúp bạn biến ý tưởng khởi nghiệp thành hiện thực. Hãy bắt đầu bằng cách chọn một gợi ý bên dưới hoặc đặt câu hỏi của riêng bạn.
      </p>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 w-full max-w-2xl">
        {/* FIX: Mapped over TOPIC_CARDS and used card.prompt to display and handle clicks. */}
        {TOPIC_CARDS.map((card, index) => (
          <button
            key={index}
            onClick={() => onSuggestionClick(card.prompt)}
            className="bg-gray-800 p-4 rounded-lg text-left hover:bg-gray-700 transition-colors duration-200"
          >
            <p className="text-gray-300">{card.prompt}</p>
          </button>
        ))}
      </div>
    </div>
  );
};
