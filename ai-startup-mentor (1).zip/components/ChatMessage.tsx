import React from 'react';
import { Message, Role } from '../types';
import { UserIcon, SparklesIcon } from './icons';

interface ChatMessageProps {
  message: Message;
  isStreaming?: boolean;
}

export const ChatMessage: React.FC<ChatMessageProps> = ({ message, isStreaming }) => {
  const isUserModel = message.role === Role.MODEL;

  // A more robust markdown-to-html conversion
  const formattedContent = message.content
    // Bold **text**
    .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
    // Italic *text*
    .replace(/\*(.*?)\*/g, '<em>$1</em>')
    // Code `text`
    .replace(/`([^`]+)`/g, '<code class="bg-gray-900/50 rounded px-1.5 py-1 text-sm font-mono text-cyan-300">$1</code>')
    // Numbered lists (1. item)
    .replace(/^\s*(\d+)\.\s+(.*)/gm, '<ol class="list-decimal list-inside ml-4"><li>$2</li></ol>')
    // Bullet points (* or - item)
    .replace(/^\s*([*-])\s+(.*)/gm, '<ul class="list-disc list-inside ml-4"><li>$2</li></ul>')
    // Combine adjacent list items of the same type
    .replace(/<\/ul>\s*<ul class="list-disc list-inside ml-4">/g, '')
    .replace(/<\/ol>\s*<ol class="list-decimal list-inside ml-4">/g, '')
    // Newlines to <br>
    .replace(/\n/g, '<br />');


  return (
    <div className="flex items-start gap-4 p-4">
      <div className={`flex-shrink-0 w-8 h-8 rounded-lg flex items-center justify-center ${isUserModel ? 'bg-gradient-to-br from-cyan-500 to-purple-600' : 'bg-gray-600'}`}>
        {isUserModel ? <SparklesIcon className="w-5 h-5 text-white" /> : <UserIcon className="w-5 h-5 text-white" />}
      </div>
      <div className="flex-1 pt-0.5 overflow-hidden">
        <p className="text-sm font-semibold text-white mb-2">{isUserModel ? 'MentorAI' : 'Bạn'}</p>
        <div 
          className="prose prose-invert prose-sm max-w-none prose-p:text-gray-300 prose-strong:text-white prose-em:text-gray-300 prose-ul:text-gray-300 prose-ol:text-gray-300"
          dangerouslySetInnerHTML={{ __html: formattedContent + (isStreaming && isUserModel ? '<span class="inline-block w-2 h-4 bg-white animate-pulse ml-1"></span>' : '') }}
        />
      </div>
    </div>
  );
};