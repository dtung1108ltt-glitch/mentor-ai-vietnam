import React from 'react';
import { MenuIcon, NewChatIcon } from './icons';

interface HeaderProps {
    onMenuClick: () => void;
    onNewChatClick: () => void;
}

export const Header: React.FC<HeaderProps> = ({ onMenuClick, onNewChatClick }) => {
    return (
        <header className="bg-[#0D1117]/80 backdrop-blur-sm border-b border-gray-800 p-4 flex items-center justify-between z-20">
            <button onClick={onMenuClick} className="md:hidden p-2 text-gray-400 hover:text-white">
                <MenuIcon className="w-6 h-6" />
            </button>
            <div className="absolute left-1/2 -translate-x-1/2 md:static md:left-auto md:translate-x-0">
                 <h1 className="text-xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-purple-500">MentorAI</h1>
            </div>
            <button onClick={onNewChatClick} className="flex items-center gap-2 text-sm bg-gray-800/50 border border-gray-700 rounded-md px-3 py-2 text-gray-300 hover:bg-gray-700/50 hover:text-white transition-colors">
                <NewChatIcon className="w-5 h-5"/>
                <span className="hidden sm:inline">Cuộc trò chuyện mới</span>
            </button>
        </header>
    );
};