import React, { useRef, useEffect } from 'react';
import { SendIcon, LoadingIcon } from './icons';

interface ChatInputProps {
  input: string;
  setInput: (value: string) => void;
  handleSend: () => void;
  isLoading: boolean;
}

export const ChatInput: React.FC<ChatInputProps> = ({ input, setInput, handleSend, isLoading }) => {
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    const textarea = textareaRef.current;
    if (textarea) {
      textarea.style.height = 'auto';
      // Limit growth to prevent huge textareas
      const maxHeight = 200; // 200px
      textarea.style.height = `${Math.min(textarea.scrollHeight, maxHeight)}px`;
    }
  }, [input]);
  
  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      if (!isLoading) {
        handleSend();
      }
    }
  };

  return (
    <div className="p-4 border-t border-gray-800">
      <div className="bg-gray-900 rounded-xl flex items-end p-2 border border-gray-700 focus-within:border-cyan-500 transition-colors">
        <textarea
          ref={textareaRef}
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder="Hỏi MentorAI..."
          className="flex-1 bg-transparent text-gray-200 placeholder-gray-500 focus:outline-none resize-none max-h-48 px-2"
          rows={1}
          disabled={isLoading}
        />
        <button
          onClick={handleSend}
          disabled={isLoading || !input.trim()}
          className="w-9 h-9 flex-shrink-0 bg-cyan-500 text-gray-900 rounded-lg flex items-center justify-center disabled:bg-gray-600 disabled:cursor-not-allowed transition-colors hover:bg-cyan-400"
          aria-label="Send message"
        >
          {isLoading ? <LoadingIcon className="w-5 h-5"/> : <SendIcon className="w-5 h-5" />}
        </button>
      </div>
    </div>
  );
};