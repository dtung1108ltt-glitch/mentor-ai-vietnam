import React, { useRef, useEffect } from 'react';
import { Message } from '../types';
import { ChatMessage } from './ChatMessage';
import { ChatInput } from './ChatInput';
import { CloseIcon } from './icons';

interface ChatPanelProps {
    messages: Message[];
    input: string;
    setInput: (value: string) => void;
    handleSend: () => void;
    isLoading: boolean;
    error: string | null;
    isOpen: boolean;
    onClose: () => void;
}

export const ChatPanel: React.FC<ChatPanelProps> = ({ messages, input, setInput, handleSend, isLoading, error, isOpen, onClose }) => {
    const messagesEndRef = useRef<HTMLDivElement>(null);

    const scrollToBottom = () => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    };

    useEffect(() => {
        scrollToBottom();
    }, [messages, isLoading]);

    return (
        <aside className={`absolute top-0 left-0 h-full w-full max-w-md bg-[#161B22] border-r border-gray-800 flex flex-col transition-transform duration-300 ease-in-out z-30
            ${isOpen ? 'translate-x-0' : '-translate-x-full'}
            md:relative md:translate-x-0 md:w-96 md:max-w-none
        `}>
            <header className="p-4 border-b border-gray-800 flex items-center justify-between flex-shrink-0">
                <h2 className="text-lg font-semibold text-white">Trò chuyện với MentorAI</h2>
                <button onClick={onClose} className="md:hidden p-2 text-gray-400 hover:text-white">
                    <CloseIcon className="w-6 h-6" />
                </button>
            </header>

            <div className="flex-1 overflow-y-auto">
                {messages.map((msg, index) => (
                    <ChatMessage
                        key={index}
                        message={msg}
                        isStreaming={isLoading && index === messages.length - 1}
                    />
                ))}
                {error && (
                    <div className="p-4">
                        <div className="bg-red-500/20 text-red-300 p-3 rounded-md text-sm">
                            {error}
                        </div>
                    </div>
                )}
                <div ref={messagesEndRef} />
            </div>

            <ChatInput
                input={input}
                setInput={setInput}
                handleSend={handleSend}
                isLoading={isLoading}
            />
        </aside>
    );
};