import React from 'react';
import { TOPIC_CARDS } from '../constants';
import { TopicCard } from './TopicCard';
import * as Icons from './icons';

interface DashboardProps {
  onTopicSelect: (prompt: string) => void;
  onStartConversation: () => void;
}

const iconMap: { [key: string]: React.FC<{ className?: string }> } = {
  IdeaIcon: Icons.IdeaIcon,
  BusinessModelIcon: Icons.BusinessModelIcon,
  MarketIcon: Icons.MarketIcon,
  MVPIcon: Icons.MVPIcon,
  FundingIcon: Icons.FundingIcon,
  SuccessIcon: Icons.SuccessIcon,
};

export const Dashboard: React.FC<DashboardProps> = ({ onTopicSelect, onStartConversation }) => {
  return (
    <div className="flex-1 overflow-y-auto p-6 md:p-10 text-white">
      <div className="max-w-4xl mx-auto">
        <header className="text-center mb-12 md:mb-16">
          <h1 className="text-4xl md:text-6xl font-extrabold mb-4 text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-purple-500">
            Xây dựng Tầm nhìn. Khởi đầu Tương lai.
          </h1>
          <p className="text-lg md:text-xl text-gray-400 max-w-2xl mx-auto">
            Người đồng hành AI của bạn trên hành trình khởi nghiệp, từ ý tưởng đến thành công.
          </p>
          <button 
            onClick={onStartConversation}
            className="mt-8 bg-cyan-500 text-gray-900 font-bold py-3 px-8 rounded-full hover:bg-cyan-400 transition-all duration-300 shadow-lg shadow-cyan-500/20 transform hover:scale-105"
          >
            Bắt đầu trò chuyện
          </button>
        </header>

        <main>
          <h2 className="text-2xl font-bold mb-8 text-center md:text-left">Tôi có thể giúp gì cho bạn hôm nay?</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {TOPIC_CARDS.map((card) => {
              const IconComponent = iconMap[card.icon];
              return (
                <TopicCard
                  key={card.title}
                  title={card.title}
                  description={card.description}
                  onClick={() => onTopicSelect(card.prompt)}
                  icon={IconComponent ? <IconComponent className="w-6 h-6 text-cyan-400" /> : null}
                />
              );
            })}
          </div>
        </main>
        
        <footer className="text-center mt-16">
            <p className="text-sm text-gray-600">
                MentorAI có thể mắc lỗi. Vui lòng xác minh các thông tin quan trọng.
            </p>
        </footer>
      </div>
    </div>
  );
};