import React from 'react';

interface TopicCardProps {
    icon: React.ReactNode;
    title: string;
    description: string;
    onClick: () => void;
}

export const TopicCard: React.FC<TopicCardProps> = ({ icon, title, description, onClick }) => {
    return (
        <button
            onClick={onClick}
            className="group relative text-left bg-[#161B22] p-6 rounded-lg transition-transform duration-300 ease-in-out hover:-translate-y-2 border border-gray-800 hover:border-cyan-500/50"
        >
             <div className="glow-border rounded-lg"></div>
            <div className="flex items-center gap-4 mb-3">
                <div className="bg-gray-800 p-2 rounded-md">
                    {icon}
                </div>
                <h3 className="text-lg font-semibold text-white">{title}</h3>
            </div>
            <p className="text-gray-400 text-sm leading-relaxed">{description}</p>
        </button>
    );
};
